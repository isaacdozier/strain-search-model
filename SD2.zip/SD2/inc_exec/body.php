<body>
    <div id="strain_txt"></div>
