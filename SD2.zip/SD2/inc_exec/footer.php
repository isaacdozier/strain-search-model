    <div class="row">
      <div class="col-sm-9">
        <h3>About</h3>
        <div class="row">
          <div class="col-xs-8 col-sm-6">
            {Social}
          </div>
          <div class="col-xs-4 col-sm-6">
            {Info}
          </div>
        </div>
      </div>
    </div>