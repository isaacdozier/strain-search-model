<html>
<head>
<title>Strains</title>
</head>
<body>
<?php
echo $_GET['strain_id'];
?>
</body>
</html>