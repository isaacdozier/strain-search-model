


<form>
<select name="users" onchange="showUser(this.value)">
  <option value="">Select a person:</option>
  <option value="1">Gods Gift</option>
  </select>
</form>
<br>
<div id="txtHint_two"><b>Strain info will be listed here...</b></div>


</body>
</html>