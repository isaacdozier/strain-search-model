<?php

class Semantics3_ParameterError extends Semantics3_Error
{
}
