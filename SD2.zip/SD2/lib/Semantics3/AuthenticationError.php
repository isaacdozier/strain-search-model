<?php

class Semantics3_AuthenticationError extends Semantics3_Error
{
}
