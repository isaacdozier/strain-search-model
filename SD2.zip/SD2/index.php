<?php include('inc_exec/header.php'); ?>

<div class="container-fluid">
    <div class="page-header">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Search for strain..." onkeyup="strain_srch_2(this.value)">
        </div><!-- /input-group -->
    </div>
 
    
    <?php include('inc_exec/body.php'); ?>
    <?php include('inc_exec/footer.php'); ?>

</div>

<?php include('inc_exec/foot.php'); ?>
